import React, { Component } from 'react';
import { AppRegistry, Text, View, TouchableHighlight, TextInput, StyleSheet, Dimensions, ImageBackground } from 'react-native';
import Constants from 'expo-constants';

let deviceHeight = Dimensions.get('window').height;
let deviceWidth = Dimensions.get('window').width;

export default class App extends Component {

   state = {
      originalBill: 0,
      billWithTip: 0,
      tip: 0,
      newTip: 0,
    }
    
    p10 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.10),
            newTip: (this.state.tip + 10),
        })
    }
    p15 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.15),
            newTip: (this.state.tip + 15),
        })
    }
    p20 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.20),
            newTip: (this.state.tip + 20),
        })
    }
    p25 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.25),
            newTip: (this.state.tip + 25),
        })
    }
    p30 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.30),
            newTip: (this.state.tip + 30),
        })
    }
    p35 = () => {
        this.setState({
            billWithTip: (this.state.originalBill * 1.35),
            newTip: (this.state.tip + 35),
        })
    }

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.titleContainer}>
                    <ImageBackground
                        style={{height: deviceHeight/6, width: deviceWidth}}
                        source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFZmBR6nfgSVp6GCYPDTwYC-BbwPqkPiB4m2Q7QCtb8tJX9RlGS-_kfkbdYzGb8gXy2JY&usqp=CAU' }}
                    >
                        <View style={styles.titleContainer}>
                            <Text style={styles.title}>
                                Mehers Tip Calculator
                            </Text>
                        </View>
                </ImageBackground>
                </View>
                
                <Text style={{fontSize: 25, color: "white", textAlign: "center", margin: 5}}>
                    Input Original Bill
                </Text>
                
                <TextInput style={{fontSize: 30, color: "#b83c70", textAlign: "center"}}
                    onChangeText={(originalBill) => this.setState({originalBill})}
                    value={this.state.originalBill}
                />
            
                <View style={styles.buttonContainer}>
                    <TouchableHighlight style={styles.button}
                        onPress = {this.p10}
                    >
                        <Text style={styles.buttonText}>
                            10%
                        </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={styles.button}
                        onPress = {this.p15}
                    >
                        <Text style={styles.buttonText}>
                            15%
                        </Text>
                    </TouchableHighlight>
                </View>
                
                <View style={styles.buttonContainer}>
                    <TouchableHighlight style={styles.button}
                        onPress = {this.p20}
                    >
                        <Text style={styles.buttonText}>
                            20%
                        </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={styles.button}
                        onPress = {this.p25}
                    >
                        <Text style={styles.buttonText}>
                            25%
                        </Text>
                    </TouchableHighlight>
                </View>
                
                <View style={styles.buttonContainer}>
                    <TouchableHighlight style={styles.button}
                        onPress = {this.p30}
                    >
                        <Text style={styles.buttonText}>
                            30%
                        </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={styles.button}
                        onPress = {this.p35}
                    >
                        <Text style={styles.buttonText}>
                            35%
                        </Text>
                    </TouchableHighlight>
                </View>
                <Text style={styles.paragraph}>
                    {this.state.originalBill} with {this.state.newTip} % tip:
                </Text>
                <Text style={styles.paragraph}>
                    $ {this.state.billWithTip.toFixed(2)}
                </Text>
                
            </View>
      );
   }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#4db3e4',
    },
    titleContainer: {
        height: deviceHeight/6,
        width: deviceWidth,
    },
    title: {
        color: 'black',
        fontSize: 35,
        textAlign: 'center',
        fontWeight: 'bold',
        marginBottom: 10,
    },
    paragraph: {
        color: '#b83c70',
        fontSize: 30,
        textAlign: 'center',
        marginTop: 10,
    },
    buttonContainer: {
        flexDirection: 'row',
        width: deviceWidth,
    },
    button: {
        height: 50,
        width: 100,
        backgroundColor: '#fda649',
        borderColor: 'white',
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10,
        marginLeft: 30,
    },
    buttonText: {
        color: 'white',
        fontSize: 25,
        textAlign: 'center',
    },
});
